#  [markdown]
import argparse
args=None
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    #now_ts = basic.stamp_now()
    parser.add_argument('--data_dir', type=str, default='data', help='Base directory Containing Data')
    parser.add_argument('--test_set', type=str, default='test', help='File name for testing data') 
    parser.add_argument('--train_set', type=str, default='train', help='File name for training data') #
    parser.add_argument('--val_set', type=str, default='val', help='File name for validation data')

    parser.add_argument('--seq_len', type=int, default=24, help='Sequence length - no of past time steps')

    parser.add_argument('--result_dir', type=str, default='result',  
                        help='Base Directory for saving visualizations') #
    parser.add_argument('--model_names', type=str, default='get_oracle_24_24' , help='csv model names') #
    parser.add_argument('--rla_names', type=str, default='ddpg_01' , help='csv model names') #
    # default='lstm_uni_24_1,lstmA_uni_24_1,janet_uni_24_1,janetA_uni_24_1'
    # default='get_oracle_24_1'

    parser.add_argument('--epochs', type=int, default=10_00_000, help='epochs') #
    parser.add_argument('--batch_size', type=int, default=64, help='batch_size') #
    parser.add_argument('--nval', type=int, default=10, 
                help='how many epochs to validate after, during training, should be less or equal to epochs')

    parser.add_argument('--lr', type=float, default=0.00001, help='lr') #
    parser.add_argument('--lref', type=float, default=0.2, help='lr end factor')
    #parser.add_argument('--es_patience', type=float, default=10, help='early stop patience') #
    #parser.add_argument('--es_delta', type=float, default=0.0001, help='early stop delta') #
    parser.add_argument('--buff', type=int, default=1, help='if True(1), uses i2o and o2o layers')
    parser.add_argument('--verbose', type=int, default=2, help='verbose')
    parser.add_argument('--do_train', type=int, default=1,  #
        help='if 0, skips training and evaluates only. If 1 then initialize new model, if 2 then loads existing model')
    parser.add_argument('--do_vis', type=int, default=1, help='if true, visulaizes predictions')
    parser.add_argument('--nfig', type=int, default=0, help='no of figures for manual testing')
    args = parser.parse_args()
else:
    raise Exception(f'Should not be imported!')

# python rl.py --model_names=lstm_uni_24_1,lstmA_uni_24_1 --rla_names=dqn_01 --epochs=1000
# python rl.py --model_names=janet_uni_24_1,janetA_uni_24_1

# 
#import tensorflow as tf
#tf.config.set_visible_devices([], 'GPU')

import os
import numpy as np
import matplotlib.pyplot as plt
import datetime
# #import pandas as pd
import torch as tt
# import torch.nn as nn
# import torch.optim as oo

from evc.common import now, pj
from evc.drl import RLA
from evc.common import create_default_dirs
if args.buff:
    from evc.db2 import PricePredictor
else:
    from evc.db import PricePredictor
from evc.price import PriceData, SeqDataset
create_default_dirs()

START_TIMESTAMP = now()
#  [markdown]
# # Data

# 

if args.test_set:
    csv_test = pj(f'{args.data_dir}/{args.test_set}.csv')
    assert os.path.exists(csv_test), f'test-set not found @ {csv_test}'
else:
    csv_test=None

if args.val_set:
    csv_val = pj(f'{args.data_dir}/{args.val_set}.csv')
    assert os.path.exists(csv_val), f'val-set not found @ {csv_val}'
else:
    csv_val=None

if args.do_train and args.train_set:
    csv_train = pj(f'{args.data_dir}/{args.train_set}.csv')
    assert os.path.exists(csv_train), f'train-set not found @ {csv_train}'
else:
    csv_train=None


average_past = 24
seqlen = args.seq_len
cols = ('PRICE',)
input_size = len(cols)
do_normalize=False
device = tt.device("cpu")

if csv_test is None:
    ds_test = None
else:
    ds_test  = PriceData(csv=csv_test, reverse=False)

if csv_val is None:
    ds_val=None
else:
    ds_val =  PriceData(csv=csv_val, reverse=False)
    
if args.do_train and (csv_train is not None):
    ds_train =  PriceData(csv=csv_train, reverse=False)
else:
    ds_train=None

#  [markdown]
# # Choose price predictor
net_names = args.model_names.split(',')
print(f'{net_names=}')
for name in net_names:
    assert(hasattr(PricePredictor, name)), f'name {name} not found in PricePredictor'

nets = [  getattr(PricePredictor, name)(auto_load=True) for name in net_names ]

networks = {k:n.model for k,n in zip(net_names,nets)}
network_paths = {k:n.path for k,n in zip(net_names,nets)}



import matplotlib.colors as mcolors
color_list = [*list(mcolors.TABLEAU_COLORS.keys()) , *list(mcolors.BASE_COLORS.keys())]
assert(len(networks) <= len(color_list)), f'not enough colors!'
#color_list = list(mcolors.TABLEAU_COLORS.keys())
# https://matplotlib.org/stable/gallery/color/named_colors.html
colors = {k:v for k,v in zip(networks.keys(), color_list)}

print(f'\nNetwork Paths:\n')
for k,v in network_paths.items():
    print(f'[{k}] : [{v}] @ {colors[k]}')

#  [markdown]
# > or

#  [markdown]
# # Done

trainer_call = getattr(RLA, f'{args.rla_names}')
for price_predictor,pp_model_name in zip(nets, net_names):
    trainer_call(
        ds_train, ds_val, ds_test, average_past, 
        args.lr, args.lref, args.batch_size, args.epochs, args.nval, args.result_dir, args.nfig, args.do_vis,
        price_predictor,pp_model_name)

#from known.mailer import AutoNotify#

#AutoNotify.save_login('gmail')
#nf = AutoNotify('gmail')

#nf.notify2('notify-EVC', 'nelson.navnel@gmail.com', 'mail.nelsonsharma@gmail.com')
