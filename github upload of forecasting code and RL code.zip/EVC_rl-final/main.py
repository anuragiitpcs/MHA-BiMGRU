import os

# Define the model names

# "mgru_uni_24_1", "mgruA_uni_24_1", "mgru_bi_24_1", "mgruA_bi_24_1",
# "janet_uni_24_1", "janetA_uni_24_1", "janet_bi_24_1", "janetA_bi_24_1",
# "lstm_uni_24_1", "lstmA_uni_24_1", "lstm_bi_24_1", "lstmA_bi_24_1", "get_oracle_24_1"

model_names = [
    "mgru_uni_24_1", "mgruA_uni_24_1", "mgru_bi_24_1","mgruA_bi_24_1",
    "janet_uni_24_1", "janetA_uni_24_1", "janet_bi_24_1", "janetA_bi_24_1",
    "lstm_uni_24_1", "lstmA_uni_24_1", "lstm_bi_24_1", "lstmA_bi_24_1"
]

# Command to run the code
command_template = "python rl.py --model_names={} --rla_names=ddpg_01 --result_dir=result_ddpg --epochs=210000 --do_train=1 --do_vis=1"

# Directory where results are saved
result_directory = "./result_ddpg"

# Loop through the model names and execute the code
for model_name in model_names:
    # Construct the full command
    command = command_template.format(model_name)

    # Execute the command
    os.system(command)

    # Rename the output files
    os.rename(os.path.join(result_directory, "CC_return.png"), os.path.join(result_directory, f"CC_return_{model_name}.png"))
    os.rename(os.path.join(result_directory, "EC_return.png"), os.path.join(result_directory, f"EC_return_{model_name}.png"))
    os.rename(os.path.join(result_directory, "EP_return.png"), os.path.join(result_directory, f"EP_return_{model_name}.png"))
    os.rename(os.path.join(result_directory, "output.txt"), os.path.join(result_directory, f"Episode_return_{model_name}.txt"))

    # Save the command output to a text file
    with open(os.path.join(result_directory, f"{model_name}.txt"), "w") as f:
        f.write(os.popen(command).read())
