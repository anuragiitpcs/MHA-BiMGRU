# %% Args Parse


# python38 pp.py --model_names=mgru_uni_24_1,mgruA_uni_24_1,mgru_bi_24_1,mgruA_bi_24_1,janet_uni_24_1,janetA_uni_24_1,janet_bi_24_1,janetA_bi_24_1,lstm_uni_24_1,lstmA_uni_24_1,lstm_bi_24_1,lstmA_bi_24_1  --do_train=2

# test all
# python pp.py --model_names=mgru_uni_24_1,mgruA_uni_24_1,mgru_bi_24_1,mgruA_bi_24_1,janet_uni_24_1,janetA_uni_24_1,janet_bi_24_1,janetA_bi_24_1,lstm_uni_24_1,lstmA_uni_24_1,lstm_bi_24_1,lstmA_bi_24_1  --do_train=0

# python38 pp.py --buff=1 --test_set=full --model_names=janet_uni_24_1,janetA_uni_24_1,lstm_uni_24_1,lstmA_uni_24_1 --do_train=0

# NOTE: 
# train_set : contain days (1-200)
# val_set   : contains days (201-230)
# test_set  : contains days (201-300)
import argparse
args=None
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    #now_ts = basic.stamp_now()
    parser.add_argument('--data_dir', type=str, default='data', help='Base directory Containing Data')
    parser.add_argument('--test_set', type=str, default='test', help='File name for testing data') 
    parser.add_argument('--train_set', type=str, default='train', help='File name for training data') #
    parser.add_argument('--val_set', type=str, default='val', help='File name for validation data')

    parser.add_argument('--seq_len', type=int, default=24, help='Sequence length - no of past time steps')

    parser.add_argument('--result_dir', type=str, default='result',  
                        help='Base Directory for saving visualizations') #
    parser.add_argument('--model_names', type=str, default='lstm_uni_24_1,lstmA_uni_24_1,janet_uni_24_1,janetA_uni_24_1', help='csv model names') #


    parser.add_argument('--epochs', type=int, default=200, help='epochs') #
    parser.add_argument('--batch_size', type=int, default=64, help='batch_size') #
    parser.add_argument('--nval', type=int, default=10, 
                help='how many epochs to validate after, during training, should be less or equal to epochs')

    parser.add_argument('--lr', type=float, default=0.0001, help='lr') #
    parser.add_argument('--lref', type=float, default=0.2, help='lr end factor')
    parser.add_argument('--es_patience', type=float, default=10, help='early stop patience') #
    parser.add_argument('--es_delta', type=float, default=0.0001, help='early stop delta') #

    parser.add_argument('--buff', type=int, default=1, help='if True(1), uses i2o and o2o layers')
    parser.add_argument('--verbose', type=int, default=2, help='verbose')
    parser.add_argument('--do_train', type=int, default=0,  #
        help='if 0, skips training and evaluates only. If 1 then initialize new model, if 2 then loads existing model')
    parser.add_argument('--do_vis', type=int, default=1, help='if true, visulaizes predictions')
    parser.add_argument('--nfig', type=int, default=1, help='no of figures for manual testing')
    args = parser.parse_args()
else:
    raise Exception(f'Should not be imported!')



# %% IMPORTS

# most common
import os
import numpy as np
import matplotlib.pyplot as plt
import json
# pytorch
import torch as tt
import torch.nn as nn
import torch.optim as oo

# custom
from evc.common import now, pj, pjs, create_default_dirs
from evc.price import SeqDataset, Trainer, PriceData, QuantiyMonitor
if args.buff:
    from evc.db2 import PricePredictor
else:
    from evc.db import PricePredictor
create_default_dirs()

START_TIMESTAMP = now()
# %% Select DataSet

if args.test_set:
    csv_test = pj(f'{args.data_dir}/{args.test_set}.csv')
    assert os.path.exists(csv_test), f'test-set not found @ {csv_test}'
else:
    csv_test=None

if args.val_set:
    csv_val = pj(f'{args.data_dir}/{args.val_set}.csv')
    assert os.path.exists(csv_val), f'val-set not found @ {csv_val}'
else:
    csv_val=None

if args.do_train and args.train_set:
    csv_train = pj(f'{args.data_dir}/{args.train_set}.csv')
    assert os.path.exists(csv_train), f'train-set not found @ {csv_train}'
else:
    csv_train=None

seqlen = args.seq_len
cols = ('PRICE',)
input_size = len(cols)
dt = tt.float32
do_normalize=False

if csv_test is None:
    ds_test = None
else:
    ds_test  = SeqDataset.from_csv(csv_test, cols=cols, 
                seqlen=seqlen, reverse=False, normalize=do_normalize, squeeze_label=True, dtype=dt)

if csv_val is None:
    ds_val=None
else:
    ds_val = SeqDataset.from_csv(csv_val, cols=cols, 
            seqlen=seqlen, reverse=False, normalize=do_normalize, squeeze_label=True, dtype=dt)
    
if args.do_train and (csv_train is not None):
    ds_train = SeqDataset.from_csv(csv_train, cols=cols, 
                seqlen=seqlen, reverse=False, normalize=do_normalize, squeeze_label=True, dtype=dt)
else:
    ds_train=None


#ds_train, ds_val, ds_test


#os.makedirs(f'{args.modeldir}', exist_ok=True)
# encapsulate rnns

# %%
net_names = args.model_names.split(',')
print(f'{net_names=}')
for name in net_names:
    assert(hasattr(PricePredictor, name)), f'name {name} not found in PricePredictor'

if args.do_train>0:
    auto_load = (args.do_train>1)
else:
    auto_load = True
print(f'{auto_load=}')
nets = [  getattr(PricePredictor, name)(auto_load=auto_load) for name in net_names ]

networks = {k:n.model for k,n in zip(net_names,nets)}
network_paths = {k:n.path for k,n in zip(net_names,nets)}


import matplotlib.colors as mcolors
color_list = [*list(mcolors.TABLEAU_COLORS.keys()) , *list(mcolors.BASE_COLORS.keys())]
assert(len(networks) <= len(color_list)), f'not enough colors!'
#color_list = list(mcolors.TABLEAU_COLORS.keys())
# https://matplotlib.org/stable/gallery/color/named_colors.html
colors = {k:v for k,v in zip(networks.keys(), color_list)}

print(f'\nNetwork Paths:\n')
for k,v in network_paths.items():
    print(f'[{k}] : [{v}] @ {colors[k]}')

# %% [markdown]
# # (A) Train and Evaluate

# %%

class PPTrainer(Trainer):
    def on_epoch_end(self, epoch):
        return
#        self.early_stop = self.early_stop_train(self.mean_train_loss, epoch=epoch, verbose=True)
#        if self.early_stop_train.counter==0: 
#            if self.checkpoint_path: 
#                tt.save( self.model.state_dict(), self.checkpoint_path)
#                print(f'[*] Checkpoint@ {self.checkpoint_path}')

    def on_early_stop(self, epoch):
        return
#        self.model.eval()
#        self.model.load_state_dict(tt.load(self.checkpoint_path))
#        self.model.eval()
#        print(f'[*] Restore Model from {self.checkpoint_path} @ epoch {self.early_stop_train.best_epoch}')


os.makedirs(args.result_dir, exist_ok=True)
test_loss = {}
device = tt.device("cuda:0")
if args.do_train:
    assert ds_train is not None, f'Training Data set not provided!'
    print('\n~~~~~~~~~~~~~~~~~~~[TRAINING]~~~~~~~~~~~~~~~~~~~\n')
    train_loss = {}
    for key,model in networks.items():
        model.to(device)
        total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
        print(f'\n{key} :: {total_params=}')
        epochs = args.epochs
        batch_size=args.batch_size
        shuffle=True
        validation_freq = args.nval #int(epochs/args.nval)
        criterion=nn.MSELoss()
        optimizer=oo.Adam(model.parameters(), lr=args.lr, weight_decay=0.0)
        lrs=oo.lr_scheduler.LinearLR(optimizer, start_factor= 1.0, end_factor=args.lref, total_iters=epochs)

        early_stop_train=None #QuantiyMonitor('TrainLoss', patience=args.es_patience, delta=args.es_delta)
        #early_stop_val=kt.QuantiyMonitor('ValLoss', patience=50, delta=0.00001)
        #checkpoint_freq=int(epochs/4)
        save_path=network_paths[key]
        #checkpoint_path = save_path

        trainer = PPTrainer(model)
        trainer.optimizer=optimizer
        trainer.criterion=criterion
        trainer.lrs = lrs
        trainer.early_stop_train = early_stop_train
        trainer.checkpoint_path = save_path
        trainer.fit(training_data=ds_train, validation_data=ds_val, 
                    epochs=epochs, batch_size=batch_size, shuffle=shuffle,
                    validation_freq=validation_freq,
                    save_path=save_path, verbose=args.verbose)

        loss_plot_start = 0 #int(epochs/20)
        trainer.save_results(pjs(args.result_dir, f'loss_history_{key}.npz')) # train_loss_history, val_loss_history
        #trainer.plot_results(color=colors[key],loss_plot_start=loss_plot_start)
        train_loss[key] = np.array(trainer.train_loss_history)

        if ds_test is not None:
            mtl, _ = trainer.evaluate(ds_test, batch_size=None)
            test_loss[key] = mtl
        print('=================================================')
        
    fig=plt.figure(figsize=(16,8))
    plt.ylabel('train_loss')
    for k,v in train_loss.items():
        plt.plot(np.mean(v, axis=-1)[loss_plot_start:], label=k, color=colors[k], linewidth=0.8)
    plt.legend()
    #plt.show()
    fig.savefig(pjs(args.result_dir, 'train_losses.png'))
    plt.close()
else:
    print('\n~~~~~~~~~~~~~~~~~~~[EVALUATION]~~~~~~~~~~~~~~~~~~~\n')
    if ds_test is not None:
        for key,model in networks.items():
            model.to(device)
            total_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
            print(f'\n{key} :: {total_params=}')
            trainer = PPTrainer(model)
            #trainer.optimizer=optimizer
            criterion=nn.MSELoss()
            trainer.criterion=criterion
            mtl, _ = trainer.evaluate(ds_test, batch_size=None)
            test_loss[key] = mtl
    else:
        print(f'Test data not provided!')


if ds_test is not None:
    with open(pjs(args.result_dir, 'test_losses.json'), 'w') as f: json.dump(test_loss, f)
# %% [markdown]
# # Plot Evaluation Results

# %%
if ds_test is not None:
    print('\n~~~~~~~~~~~~~~~~~~~[RESULTS]~~~~~~~~~~~~~~~~~~~\n')

    y = []
    l = []
    c = []
    for k,v in test_loss.items():
        #print(f'{k}:\t{v}')
        y.append(v)
        l.append(k)
        c.append(colors[k])

    x= range(len(test_loss))

    y = np.array(y)
    l = np.array(l)
    t = np.argsort(y)
    #for i,(yi,li,ti) in enumerate(zip(y,l,t)):
    #    print(f'[{i}] :: {yi=} :: {li=} :: {ti=}')
    #print(f'\n{y=}\n{l=}\n{t=}\n')
    fig=plt.figure(figsize=(20,6))
    plt.xlim(-1,len(x))
    #plt.ylim(0,0.001)
    print(f'\nRanked-Test-Losses:\n')
    frank = open(pjs(args.result_dir, 'ranked_test_losses.txt'), 'w')
    for rank,index in enumerate(t):
        plt.bar([rank] , [y[index]], color=c[index] )
        plt.hlines(y[index], -1, rank, linestyles='solid', linewidth=0.5, color=c[index])
        lsh = f'[{rank=}]:[{index=}] -> {l[index]}:\t{y[index]}\n'
        frank.write(lsh)
        print(lsh, end='')
    frank.close()
    plt.xticks(x, l[t])
    plt.ylabel('test_loss')
    #plt.show()
    fig.savefig(pjs(args.result_dir,'test_losses.png'))
    plt.close()

# %% [markdown]
# # Manual Testing

# %% [markdown]
# ## test dataset

# %%
if args.do_vis and (ds_val is not None):
    ds_vis = ds_val
    res = {}
    for key,model in networks.items():
        model.to(device)
        print(key, model.__class__)
        model.eval()
        with tt.no_grad():
            dl = iter(ds_vis.dataloader(batch_size=int(len(ds_vis)*1.0)))
            Xv, Yv = next(dl)
            Pv = model(Xv)
            res[key]=Pv #print(Xv.shape, Yv.shape, Pv.shape)
        key_len = (len(res[key]))

    ilen = int(key_len/args.nfig)


    print('\n~~~~~~~~~~~~~~~~~~~[PLOTTING]~~~~~~~~~~~~~~~~~~~\n')
    start_i = 0 #<--------------set this
    end_i = int(key_len)
    print(f'{ilen=}, {key_len=}, {end_i=}')

    fr, tr, cnt = (start_i)*ilen, (start_i+1)*ilen, 1
    while True:
        print(f'#{cnt} :: {fr} ==> {tr}')
        cnt+=1
        for i in range(input_size):
            fig=plt.figure(figsize=(20,10))
            plt.title(f'{i}')
            
            plt.plot(Yv[fr:tr,i], color='black', label='Truth')
            for key,r in res.items():
                plt.plot(r[fr:tr,i], color=colors[key], label=f'{key}', linewidth=0.5)
            plt.legend()
            #plt.show()
            
            fig.savefig(pjs(args.result_dir, f'Vis_{i}_{cnt}.png'))
            plt.close()
        
        
        
        fr=tr
        if fr>=end_i: break
        tr = min(tr+ilen, end_i)
        if tr>end_i: tr=end_i
else:
    print(f'Skip visuals!')
    
END_TIMESTAMP = now()
TOTAL_RUNTIME = END_TIMESTAMP-START_TIMESTAMP
print('\nTotal Runtime: {}'.format(TOTAL_RUNTIME))
